package cc.openhome;

public class Comparison {
    public static void main(String[] args) {
        System.out.printf("10 >  5 ���G %b%n", 10 > 5); 
        System.out.printf("10 >= 5 ���G %b%n", 10 >= 5); 
        System.out.printf("10 <  5 ���G %b%n", 10 < 5); 
        System.out.printf("10 <= 5 ���G %b%n", 10 <= 5); 
        System.out.printf("10 == 5 ���G %b%n", 10 == 5); 
        System.out.printf("10 != 5 ���G %b%n", 10 != 5);
    }
}
